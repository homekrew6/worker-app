
# [0.5.18](https://github.com/GeekyAnts/NativeBase-KitchenSink/releases/tag/v0.5.18)

### Bug Fixes

- **ReactNativePropRegistry:** Fixed with commit [f3f0d8e](https://github.com/GeekyAnts/NativeBase-KitchenSink/commit/f3f0d8e98108e3288dd702d103f65e994de78151).

### Enhancement Features

- **Upgrade:** Upgraded versions of React, [React Native](https://facebook.github.io/react-native/), [NativeBase](http://nativebase.io/), [CodePush](https://github.com/Microsoft/react-native-code-push), [Easy-Grid](https://github.com/GeekyAnts/react-native-easy-grid).
