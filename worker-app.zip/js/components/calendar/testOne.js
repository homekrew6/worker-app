import React, { Component } from 'react';
import { View, Text } from 'react-native';


  const testOne = this.state.dat.availableTimings.availability.map(Slot => {
      return (
        <Text>ryt</Text>
      );
  });


export default testOne;
