export default {
  greeting: 'Bonjour!',
  username: 'Username',
  password: 'Password',
  done:'Terminé'
};
