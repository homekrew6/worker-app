const config = {
  
  // base_api: 'http://192.168.1.38:3000/api/',
  // base_api: 'http://192.168.1.37:3000/api/',
  base_api: 'http://18.130.45.57:3000/api/',
  // base_api : 'http://192.168.1.118:3000/api/',
  // base_api: 'http://111.93.169.90:3000/api/',

  krew_vertical_id : 1,
  s3: {
    keyPrefix: "",
    bucket: "homekrewbooking",
    region: "eu-central-1",
    accessKey: "AKIAJUKBBDPNW5ED2M2A",
    secretKey: "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",
    successActionStatus: 201
  }
}

export default config;
