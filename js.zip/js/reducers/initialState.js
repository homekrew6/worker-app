export default {
	auth: {
		loggedIn : false,
		busy:false,
		data:''
	},
	location: {
		busy: false,
		data: '',
		selectedData: ''
	},
	payment:{
		busy:false,
		data:''
	},
	availableJobs: {
		busy: false,
		data: ''
	}
}
