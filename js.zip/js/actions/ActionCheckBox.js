export function ChangeCheckBox(time, day, id, dataRemote){
  return(dispatch => {
    dispatch({ type: 'none' });
  });

}
